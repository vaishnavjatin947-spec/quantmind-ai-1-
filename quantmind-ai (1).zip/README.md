# QuantMind AI — React UI (Vite + Tailwind)

## Quick start

1. Install dependencies:
   ```bash
   npm install
   ```
2. Run dev server:
   ```bash
   npm run dev
   ```
3. Build for production:
   ```bash
   npm run build
   ```

This project contains the QuantMind UI component at `src/QuantMindUI.jsx`.
Replace mock data and wire APIs as needed. Deploy to Vercel by pushing this repo to GitHub and connecting it to Vercel.
