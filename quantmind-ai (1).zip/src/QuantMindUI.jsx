/*
QuantMind AI — Single-file React component (Tailwind). 
Usage:
1) Create a React app (Vite or Create React App). Tailwind + Recharts + lucide-react + framer-motion + shadcn/ui recommended.
2) Place this file as src/QuantMindUI.jsx and import it in App.jsx: `import QuantMindUI from './QuantMindUI'` then render <QuantMindUI />.
3) Install dependencies:
   npm i recharts framer-motion lucide-react @radix-ui/react-avatar @radix-ui/react-dropdown-menu
   (shadcn/ui components are optional — component placeholders used.)
4) Tailwind: ensure tailwind is configured in your project.
5) To deploy: push to GitHub and connect to Vercel or Netlify.

This single-file component contains a clean dashboard layout with: header, sidebar, KPI cards, a chart area (Recharts), recent activity list, and a settings panel. Replace mock data with your API responses.
*/

import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { Menu, MoreHorizontal, User, Settings } from 'lucide-react'
import { motion } from 'framer-motion'

const mockKpis = [
  { id: 1, title: 'Active Models', value: 12, change: '+8%' },
  { id: 2, title: 'Requests / min', value: 1_240, change: '+3.4%' },
  { id: 3, title: 'Avg Latency (ms)', value: 184, change: '-5.1%' },
  { id: 4, title: 'Uptime', value: '99.97%', change: '+0.01%' }
]

const mockChart = [
  { name: '00:00', requests: 300 },
  { name: '02:00', requests: 420 },
  { name: '04:00', requests: 380 },
  { name: '06:00', requests: 560 },
  { name: '08:00', requests: 700 },
  { name: '10:00', requests: 1020 },
  { name: '12:00', requests: 1240 },
  { name: '14:00', requests: 980 },
  { name: '16:00', requests: 760 },
  { name: '18:00', requests: 900 },
  { name: '20:00', requests: 1100 },
  { name: '22:00', requests: 950 }
]

const recentActivity = [
  { id: 1, time: '2m ago', text: 'Model `qm-alpha` completed fine-tuning.' },
  { id: 2, time: '7m ago', text: 'API key rotated for project `trading-bot`.' },
  { id: 3, time: '25m ago', text: 'Prediction job #7945 failed (memory limit).' },
  { id: 4, time: '1h ago', text: 'New dataset uploaded: `market-2025-q3`.' }
]

export default function QuantMindUI() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 antialiased">
      <div className="flex">
        {/* SIDEBAR */}
        <aside className="w-72 bg-white border-r border-slate-200 min-h-screen sticky top-0">
          <div className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-bold">QM</div>
              <div>
                <div className="font-semibold">QuantMind AI</div>
                <div className="text-xs text-slate-500">Platform · Dashboard</div>
              </div>
            </div>

            <nav className="mt-8">
              <ul className="space-y-1">
                <li className="p-2 rounded hover:bg-slate-100 cursor-pointer">Dashboard</li>
                <li className="p-2 rounded hover:bg-slate-100 cursor-pointer">Models</li>
                <li className="p-2 rounded hover:bg-slate-100 cursor-pointer">Datasets</li>
                <li className="p-2 rounded hover:bg-slate-100 cursor-pointer">Jobs</li>
                <li className="p-2 rounded hover:bg-slate-100 cursor-pointer">API Keys</li>
                <li className="p-2 rounded hover:bg-slate-100 cursor-pointer">Settings</li>
              </ul>
            </nav>

            <div className="mt-6">
              <button className="w-full py-2 px-3 bg-indigo-600 text-white rounded-lg shadow-sm">Create Model</button>
            </div>

            <div className="mt-6 text-xs text-slate-500">v1.0 · Live</div>
          </div>
        </aside>

        {/* MAIN */}
        <main className="flex-1 p-6">
          {/* HEADER */}
          <header className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button className="p-2 rounded bg-white border border-slate-200"><Menu size={16} /></button>
              <div>
                <h1 className="text-2xl font-bold">Dashboard</h1>
                <p className="text-sm text-slate-500">Overview of models, jobs and traffic</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center bg-white border border-slate-200 rounded-md py-1 px-3 gap-2">
                <input className="outline-none text-sm" placeholder="Search models, datasets..." />
                <button className="text-slate-500"><MoreHorizontal size={16} /></button>
              </div>

              <div className="flex items-center gap-3">
                <button className="p-2 rounded hover:bg-slate-100"><Settings size={16} /></button>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center"><User size={14} /></div>
                  <div className="text-sm">
                    <div className="font-medium">Jatin</div>
                    <div className="text-xs text-slate-500">Admin</div>
                  </div>
                </div>
              </div>
            </div>
          </header>

          {/* KPI CARDS */}
          <section className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {mockKpis.map(k => (
              <motion.div key={k.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
                <div className="text-xs text-slate-500">{k.title}</div>
                <div className="mt-2 flex items-baseline justify-between">
                  <div className="text-2xl font-semibold">{k.value.toLocaleString ? k.value.toLocaleString() : k.value}</div>
                  <div className={`text-sm font-medium ${k.change.startsWith('-') ? 'text-red-500' : 'text-green-600'}`}>{k.change}</div>
                </div>
              </motion.div>
            ))}
          </section>

          {/* Main Grid */}
          <section className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-slate-500">Traffic</div>
                  <div className="text-lg font-semibold">Requests per hour</div>
                </div>
                <div className="text-sm text-slate-500">Last 24 hours</div>
              </div>

              <div className="mt-4 h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={mockChart} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e6e6e6" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="requests" stroke="#6366f1" strokeWidth={3} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-lg border border-slate-100 bg-slate-50">
                  <div className="text-xs text-slate-500">Top Model</div>
                  <div className="mt-1 font-medium">qm-alpha</div>
                </div>
                <div className="p-3 rounded-lg border border-slate-100 bg-slate-50">
                  <div className="text-xs text-slate-500">Active Jobs</div>
                  <div className="mt-1 font-medium">6</div>
                </div>
                <div className="p-3 rounded-lg border border-slate-100 bg-slate-50">
                  <div className="text-xs text-slate-500">Pending Alerts</div>
                  <div className="mt-1 font-medium">2</div>
                </div>
              </div>
            </div>

            <aside className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold">Recent Activity</div>
                <div className="text-xs text-slate-400">View all</div>
              </div>

              <ul className="mt-3 space-y-3">
                {recentActivity.map(a => (
                  <li key={a.id} className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-xs font-medium">A</div>
                    <div className="flex-1 text-sm">
                      <div className="text-slate-700">{a.text}</div>
                      <div className="text-xs text-slate-400">{a.time}</div>
                    </div>
                  </li>
                ))}
              </ul>

              <div className="mt-4">
                <button className="w-full py-2 rounded-md border border-slate-100">View Activity Log</button>
              </div>
            </aside>
          </section>

          {/* FOOTER / SETTINGS */}
          <section className="mt-6">
            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-semibold">Quick Settings</div>
                  <div className="text-xs text-slate-500">Manage environment & API keys</div>
                </div>
                <div>
                  <button className="py-2 px-3 bg-emerald-600 text-white rounded-md">Open Settings</button>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}
