import React from 'react'
import QuantMindUI from './QuantMindUI'

export default function App() {
  return <QuantMindUI />
}
